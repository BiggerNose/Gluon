/* gripper.h */

#ifndef GRIPPER_H
#define GRIPPER_H

#include <ros/ros.h>

class Gripper {
public:
    Gripper(ros::NodeHandle& nh); // Constructor

    bool open(); // Function to open the gripper
    bool release(); // Function to release the gripper
    bool close(); // Function to close the gripper
    bool closeHalf(); // Function to close the gripper

private:
    ros::NodeHandle node_handle;
};

#endif // GRIPPER_H
