# How to use the header file example:

#include "ros/ros.h"
#include "gripper.h"

int main(int argc, char** argv) {
    ros::init(argc, argv, "example_node");
    ros::NodeHandle nh;

    Gripper gripper(nh); // Pass the NodeHandle to the Gripper constructor

    Available Commands for the gripper
    ==================================
    gripper.open();
    gripper.release();
    gripper.close();
    gripper.closeHalf();
    ==================================

    ros::spin();

    return 0;
}

