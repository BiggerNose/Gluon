/* gripper.cpp */
#include "gripper.h"

// Dynamixel
#include "dynamixel_workbench_msgs/DynamixelCommand.h"
#include "dynamixel_workbench_msgs/DynamixelStateList.h"
#include "dynamixel_workbench_msgs/DynamixelState.h"

#define DXL_LEFT 1
#define DXL_RIGHT 2
#define ADDRESS "Goal_Position"

Gripper::Gripper(ros::NodeHandle& nh) : node_handle(nh) {
    // Initialize the serviceClient.
    goal_dynamixel_command_client_ = nh.serviceClient<dynamixel_workbench_msgs::DynamixelCommand>("dynamixel_workbench/dynamixel_command");
}

bool Gripper::open() {
    // Set the variables to open the gripper.
    dynamixel_workbench_msgs::DynamixelCommand open;
    open.request.id_1 = DXL_LEFT;
    open.request.id_2 = DXL_RIGHT;
    open.request.addr_name_1 = ADDRESS;
    open.request.addr_name_2 = ADDRESS;
    open.request.value_1 = 330;
    open.request.value_2 = 730;

    // Call dynamixel service to open the gripper.
    // If the call was successful -> "Gripper Opened" otherwise, "Failed to Open Gripper".
    if (goal_dynamixel_command_client_.call(open)) ? ROS_INFO("Gripper Opened") : ROS_ERROR("Failed to Open Gripper");
    
    return true; // Return true if the command was successful; otherwise, return false.
}

bool Gripper::release() {
    // Set the variables to release a object from the gripper.
    dynamixel_workbench_msgs::DynamixelCommand release;
    release.request.id_1 = DXL_LEFT;
    release.request.id_2 = DXL_RIGHT;
    release.request.addr_name_1 = ADDRESS;
    release.request.addr_name_2 = ADDRESS;
    release.request.value_1 = 470;
    release.request.value_2 = 550;

    // Call dynamixel service to release the gripper.
    // If the call was successful -> "Gripper Released" otherwise, "Failed to Released Gripper".
    if (goal_dynamixel_command_client_.call(release)) ? ROS_INFO("Gripper Released") : ROS_ERROR("Failed to Released Gripper");
    
    return true; // Return true if the command was successful; otherwise, return false.
}

bool Gripper::close() {
    // Set the variables to close the gripper.
    dynamixel_workbench_msgs::DynamixelCommand close;
    close.request.id_1 = DXL_LEFT;
    close.request.id_2 = DXL_RIGHT;
    close.request.addr_name_1 = ADDRESS;
    close.request.addr_name_2 = ADDRESS;
    close.request.value_1 = 542;
    close.request.value_2 = 482;

    // Call dynamixel service to close the gripper.
    // If the call was successful -> "Gripper Closed" otherwise, "Failed to Close Gripper".
    if (goal_dynamixel_command_client_.call(close)) ? ROS_INFO("Gripper Closed") : ROS_ERROR("Failed to Close Gripper");

    return true; // Return true if the command was successful; otherwise, return false.
}

bool Gripper::closeHalf() {
    // Set the variables to close the gripper half way.
    dynamixel_workbench_msgs::DynamixelCommand close_half;
    close_half.request.id_1 = DXL_LEFT;
    close_half.request.id_2 = DXL_RIGHT;
    close_half.request.addr_name_1 = ADDRESS;
    close_half.request.addr_name_2 = ADDRESS;
    close_half.request.value_1 = 520;
    close_half.request.value_2 = 505;

    // Call dynamixel service to close the gripper half way.
    // If the call was successful -> "Gripper Closed Half Way" otherwise, "Failed to Close Gripper Half Way".
    if (goal_dynamixel_command_client_.call(close_half)) ? ROS_INFO("Gripper Closed Half Way") : ROS_ERROR("Failed to Close Gripper Half Way");

    return true; // Return true if the command was successful; otherwise, return false.
}
